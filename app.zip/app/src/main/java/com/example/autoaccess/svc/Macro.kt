package com.example.autoaccess.svc

import org.json.JSONArray
import org.json.JSONObject

/** Mô tả một macro */
data class Macro(
    val id: String,
    val version: Int = 1,
    val steps: List<Step>
)

/** Các bước hành động hỗ trợ */
sealed interface Step {

    // ——— Tap
    data class Tap(val x: Int, val y: Int, val ms: Long = 80L) : Step
    data class TapRand(
        val x: Int, val y: Int, val ms: Long = 80L,
        val randDx: Int = 0, val randDy: Int = 0, val randDt: Int = 0
    ) : Step
    data class TapOffset(
        val x: Int, val y: Int, val dx: Int, val dy: Int, val ms: Long = 80L
    ) : Step

    // ——— Sleep
    data class Sleep(val ms: Long) : Step
    data class SleepRand(val minMs: Long, val maxMs: Long) : Step

    // ——— Swipe
    data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val ms: Long = 300L) : Step
    data class SwipeRand(
        val x1: Int, val y1: Int, val x2: Int, val y2: Int,
        val ms: Long = 300L, val rand: Int = 0, val randDt: Int = 0
    ) : Step

    // ——— Phím hệ thống
    data class Key(val key: String) : Step // home | back | menu/recents

    // ——— Repeat
    data class Repeat(
        val steps: List<Step>,
        val count: Int? = null,            // repeat N lần
        val maxLoops: Int? = null,         // an toàn cho repeat vô hạn
        val until: String? = null          // để dành cho dừng theo điều kiện
    ) : Step

    // ——— Call alias
    data class Call(val name: String, val args: Map<String, Any?> = emptyMap()) : Step

    // ——— Các type liên quan hình ảnh (để exhaustive trong when)
    data class FindImage(val id: String, val timeoutMs: Long = 2000) : Step
    data class TapImage(val id: String) : Step
    data class SwipeImage(val id: String, val dx: Int, val dy: Int) : Step
    data class WaitImage(val id: String, val timeoutMs: Long = 2000) : Step
}

/** Lưu alias dạng JSON ({"steps":[ ... ]}) */
object AliasRegistry {
    private val map = LinkedHashMap<String, String>()
    fun put(name: String, contentJson: String) { map[name] = contentJson }
    fun get(name: String): String? = map[name]

    /** Trả về steps đã parse; nếu có args thì có thể thay thế biến sau này */
    fun resolveSteps(name: String, args: Map<String, Any?> = emptyMap()): List<Step>? {
        val raw = map[name] ?: return null
        // hiện dùng trực tiếp, chưa thay biến theo args
        return MacroParser.parseSteps(JSONObject(raw).getJSONArray("steps"))
    }
}

/** Parser JSON → Macro/Steps (đơn giản, đủ các step ở trên) */
object MacroParser {

    fun parse(json: String): Macro = parse(JSONObject(json))

    fun parse(obj: JSONObject): Macro {
        val id = obj.optString("id", "macro")
        val ver = obj.optInt("version", 1)
        val steps = parseSteps(obj.getJSONArray("steps"))
        return Macro(id, ver, steps)
    }

    fun parseSteps(arr: JSONArray): List<Step> {
        val out = ArrayList<Step>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val type = o.getString("type")
            when (type) {
                // Tap
                "Tap" -> out += Step.Tap(o.getInt("x"), o.getInt("y"), o.optLong("ms", 80L))
                "TapRand" -> out += Step.TapRand(
                    o.getInt("x"), o.getInt("y"), o.optLong("ms", 80L),
                    o.optInt("randDx", 0), o.optInt("randDy", 0), o.optInt("randDt", 0)
                )
                "TapOffset" -> out += Step.TapOffset(
                    o.getInt("x"), o.getInt("y"), o.optInt("dx", 0), o.optInt("dy", 0), o.optLong("ms", 80L)
                )

                // Sleep
                "Sleep" -> out += Step.Sleep(o.getLong("ms"))
                "SleepRand" -> out += Step.SleepRand(o.getLong("minMs"), o.getLong("maxMs"))

                // Swipe
                "Swipe" -> out += Step.Swipe(
                    o.getInt("x1"), o.getInt("y1"), o.getInt("x2"), o.getInt("y2"), o.optLong("ms", 300L)
                )
                "SwipeRand" -> out += Step.SwipeRand(
                    o.getInt("x1"), o.getInt("y1"), o.getInt("x2"), o.getInt("y2"),
                    o.optLong("ms", 300L), o.optInt("rand", 0), o.optInt("randDt", 0)
                )

                // Keys
                "Key" -> out += Step.Key(o.getString("key"))

                // Repeat
                "Repeat" -> {
                    val inner = parseSteps(o.getJSONArray("steps"))
                    val count = if (o.has("count") && !o.isNull("count")) o.getInt("count") else null
                    val maxLoops = if (o.has("maxLoops") && !o.isNull("maxLoops")) o.getInt("maxLoops") else null
                    val until = if (o.has("until") && !o.isNull("until")) o.getString("until") else null
                    out += Step.Repeat(inner, count, maxLoops, until)
                }

                // Call alias
                "Call" -> {
                    val name = o.getString("name")
                    val args = if (o.has("args")) {
                        val jo = o.getJSONObject("args")
                        jo.keys().asSequence().associateWith { k -> jo.get(k) }
                    } else emptyMap()
                    out += Step.Call(name, args)
                }

                // Image-related (placeholder)
                "FindImage" -> out += Step.FindImage(o.getString("id"), o.optLong("timeoutMs", 2000L))
                "TapImage" -> out += Step.TapImage(o.getString("id"))
                "SwipeImage" -> out += Step.SwipeImage(o.getString("id"), o.optInt("dx", 0), o.optInt("dy", 0))
                "WaitImage" -> out += Step.WaitImage(o.getString("id"), o.optLong("timeoutMs", 2000L))

                else -> error("Unknown step type: $type")
            }
        }
        return out
    }
}
