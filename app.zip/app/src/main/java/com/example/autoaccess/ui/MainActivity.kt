package com.example.autoaccess.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity        // <-- Sửa đúng androidx
import androidx.core.content.ContextCompat
import com.example.autoaccess.databinding.ActivityMainBinding
import com.example.autoaccess.svc.GestureEngine       // <-- đổi đúng package class service của bạn

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnStart.setOnClickListener {
            // start foreground service (compat cho API < 26)
            ContextCompat.startForegroundService(
                this,
                Intent(this, GestureEngine::class.java)  // <-- class service thật của bạn
            )
            Toast.makeText(this, "HTTP server starting…", Toast.LENGTH_SHORT).show()
        }

        b.btnStop.setOnClickListener {
            stopService(Intent(this, GestureEngine::class.java))
            Toast.makeText(this, "HTTP server stopped", Toast.LENGTH_SHORT).show()
        }

        b.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }
}