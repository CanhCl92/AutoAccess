package com.example.autoaccess.svc

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service dùng để thực thi cử chỉ hệ thống.
 * - Cung cấp hàm công khai: tap(), swipe(), back(), home(), recent()
 * - Tạo singleton instance để HttpServer gọi sang.
 */
class AccessibilitySvc : AccessibilityService() {

    companion object {
        @Volatile var instance: AccessibilitySvc? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i("AutoAccess", "AccessibilitySvc connected")

        // Nạp alias đã lưu (để Macro engine/trình khác dùng)
        try {
            val sp = getSharedPreferences("aliases", MODE_PRIVATE)
            for ((k, v) in sp.all) if (v is String) AliasRegistry.put(k, v)
        } catch (t: Throwable) {
            Log.w("AutoAccess", "load aliases failed", t)
        }

        // Bật HTTP server nếu chưa chạy
        if (!HttpServer.isRunning()) {
            HttpServer.start(applicationContext)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("AutoAccess", "AccessibilitySvc destroyed")
        HttpServer.stop()
        instance = null
    }

    override fun onInterrupt() {
        // no-op
    }

    // BẮT BUỘC override, kể cả khi không xử lý sự kiện
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Không xử lý gì; mục tiêu là điều khiển cử chỉ chủ động
    }

    // -------------------- Public API (được HttpServer gọi) --------------------

    /** Thực thi 1 lần chạm tại (x,y) với độ dài [durMs] mili-giây (mặc định 80ms). */
    fun tap(x: Float, y: Float, durMs: Long = 80L) {
        val g = buildTap(x.toInt(), y.toInt(), durMs)
        dispatchGesture(g, null, null)
    }

    /** Vuốt từ (x1,y1) tới (x2,y2) trong [durMs] mili-giây (mặc định 300ms). */
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long = 300L) {
        val g = buildSwipe(x1.toInt(), y1.toInt(), x2.toInt(), y2.toInt(), durMs)
        dispatchGesture(g, null, null)
    }

    /** Nút Back hệ thống. */
    fun back()   { performGlobalAction(GLOBAL_ACTION_BACK) }

    /** Về Home. */
    fun home()   { performGlobalAction(GLOBAL_ACTION_HOME) }

    /** Mở Recents. */
    fun recent() { performGlobalAction(GLOBAL_ACTION_RECENTS) }

    // -------------------- Gesture builders (đang dùng bởi API trên) --------------------

    fun buildTap(x: Int, y: Int, ms: Long = 80L): GestureDescription {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(p, 0, ms.coerceAtLeast(1L))
        return GestureDescription.Builder().addStroke(stroke).build()
    }

    fun buildSwipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long = 300L): GestureDescription {
        val p = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val dur = ms.coerceAtLeast(1L)
        val stroke = if (Build.VERSION.SDK_INT >= 26)
            GestureDescription.StrokeDescription(p, 0, dur, /*willContinue=*/false)
        else
            GestureDescription.StrokeDescription(p, 0, dur)
        return GestureDescription.Builder().addStroke(stroke).build()
    }
}