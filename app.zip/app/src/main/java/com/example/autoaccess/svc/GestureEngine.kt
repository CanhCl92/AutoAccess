package com.example.autoaccess.svc

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.util.Log
import kotlin.random.Random
import java.util.concurrent.CountDownLatch

class GestureEngine {

    @Volatile private var running = false
    @Volatile var currentStep: Int = -1
        private set
    @Volatile var currentMacroId: String? = null
        private set

    private var worker: Thread? = null

    fun isRunning(): Boolean = running

    fun run(macro: Macro) {
        stop()
        running = true
        currentStep = -1
        currentMacroId = macro.id

        worker = Thread {
            try {
                execSteps(macro.steps)
            } catch (ie: InterruptedException) {
                throw ie
            } catch (t: Throwable) {
                Log.e("AutoAccess", "engine crashed", t)
            } finally {
                running = false
                currentStep = -1
                currentMacroId = null
                Log.i("AutoAccess", "engine finished")
            }
        }
        worker!!.start()
        Log.i("AutoAccess", "engine start id=${macro.id} steps=${macro.steps.size}")
    }

    fun stop() {
        worker?.interrupt()
        worker = null
        running = false
    }

    private fun execSteps(steps: List<Step>) {
        var i = 0
        while (i < steps.size && !Thread.currentThread().isInterrupted) {
            currentStep = i
            when (val s = steps[i]) {

                is Step.Tap       -> tap(s.x, s.y, s.ms)
                is Step.TapRand   -> tapRandom(s.x, s.y, s.ms, s.randDx, s.randDy, s.randDt)
                is Step.TapOffset -> tap(s.x + s.dx, s.y + s.dy, s.ms)

                is Step.Sleep     -> sleepMs(s.ms)
                is Step.SleepRand -> sleepMs(randBetween(s.minMs, s.maxMs))

                is Step.Swipe     -> swipe(s.x1, s.y1, s.x2, s.y2, s.ms)
                is Step.SwipeRand -> {
                    val dx1 = randZero(s.rand); val dy1 = randZero(s.rand)
                    val dx2 = randZero(s.rand); val dy2 = randZero(s.rand)
                    val t   = s.ms + randZero(s.randDt).toLong()
                    swipe(s.x1 + dx1, s.y1 + dy1, s.x2 + dx2, s.y2 + dy2, t)
                }

                is Step.Key       -> when (s.key.lowercase()) {
                    "home" -> globalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    "back" -> globalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    "menu", "recent", "recents" ->
                        globalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    else  -> Log.w("AutoAccess", "Unknown key: ${s.key}")
                }

                is Step.Repeat    -> {
                    val body = s.steps
                    val count = s.count
                    val maxLoops = s.maxLoops ?: 10_000
                    if (count != null) {
                        repeat(count) {
                            if (Thread.currentThread().isInterrupted) return
                            execSteps(body)
                        }
                    } else {
                        var loops = 0
                        while (!Thread.currentThread().isInterrupted && loops < maxLoops) {
                            execSteps(body)
                            loops++
                            if (s.until != null) {
                                Log.w("AutoAccess", "Repeat.until not implemented yet")
                                break
                            }
                        }
                    }
                }

                is Step.Call      -> {
                    val aliasSteps = AliasRegistry.resolveSteps(s.name, s.args)
                    if (aliasSteps == null) Log.w("AutoAccess", "Alias not found: ${s.name}")
                    else execSteps(aliasSteps)
                }

                // Image actions chưa bật: log cho đủ exhaustive
                is Step.FindImage,
                is Step.TapImage,
                is Step.SwipeImage,
                is Step.WaitImage -> {
                    Log.w("AutoAccess", "Image actions disabled in this build")
                }
            }
            i++
        }
    }

    // ------------ primitives ------------

    private fun tap(x: Int, y: Int, ms: Long) {
        val svc = AccessibilitySvc.instance ?: return
        dispatch(svc.buildTap(x, y, ms))
    }

    private fun tapRandom(
        x: Int, y: Int, ms: Long,
        randDx: Int, randDy: Int, randDt: Int
    ) {
        val dx = randZero(randDx)
        val dy = randZero(randDy)
        val dt = ms + randZero(randDt).toLong()
        tap(x + dx, y + dy, dt)
    }

    private fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long) {
        val svc = AccessibilitySvc.instance ?: return
        dispatch(svc.buildSwipe(x1, y1, x2, y2, ms))
    }

    private fun globalAction(action: Int) {
        AccessibilitySvc.instance?.performGlobalAction(action)
        try { Thread.sleep(120) } catch (ie: InterruptedException) { throw ie }
    }

    private fun sleepMs(ms: Long) {
        if (ms <= 0L) return
        try { Thread.sleep(ms) } catch (ie: InterruptedException) { throw ie }
    }

    private fun dispatch(g: GestureDescription) {
        val svc = AccessibilitySvc.instance ?: return
        val latch = CountDownLatch(1)
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.i("AutoAccess", "gesture completed"); latch.countDown()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w("AutoAccess", "gesture cancelled"); latch.countDown()
            }
        }
        svc.dispatchGesture(g, cb, null)
        try { latch.await() } catch (ie: InterruptedException) { throw ie }
    }

    private fun randZero(range: Int): Int =
        if (range <= 0) 0 else Random.nextInt(-range, range + 1)

    private fun randBetween(min: Long, max: Long): Long {
        if (max <= min) return min
        val delta = (max - min).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        return min + Random.nextInt(0, delta + 1)
    }
}