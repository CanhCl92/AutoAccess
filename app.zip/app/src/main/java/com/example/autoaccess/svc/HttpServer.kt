package com.example.autoaccess.svc

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.util.Log
import androidx.core.content.edit
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * HTTP server điều khiển macro/alias + lệnh trực tiếp qua ADB port-forward.
 * Port mặc định: 8765
 *
 * Endpoint:
 *  GET  /ping                       -> {"ok":true}
 *  GET  /status                     -> {"running":bool,"id":..., "step":int}
 *  POST /macro   (application/json) -> lưu macro JSON {id, version, steps}
 *  POST /run     (application/json) -> {"id":"macroId"}
 *  POST /stop                      -> dừng engine
 *
 *  POST /alias   (application/json) -> {"name":"...", "steps":[...]} : lưu alias
 *  GET  /alias                      -> {"aliases":["a","b",...]}
 *
 *  POST /image?id=xxx (binary)      -> upload ảnh png vào store (ImageStore)
 *  GET  /image                      -> {"images":[{"id":"...", "w":.., "h":..}, ...]}
 *  DELETE /image?id=xxx             -> {"ok":true/false}
 *
 *  --- Lệnh trực tiếp (mới thêm) ---
 *  POST /cmd  (application/json)    -> {"op":"tap|swipe|back|home|recent", ...}
 *      tap   : {"op":"tap","x":..,"y":..,"dur":ms?}
 *      swipe : {"op":"swipe","x":..,"y":..,"x2":..,"y2":..,"dur":ms?}
 *      back/home/recent : {"op":"back"}
 */
@SuppressLint("StaticFieldLeak") // chỉ giữ Application, không giữ Activity/Service
object HttpServer {

    private var server: Srv? = null
    private lateinit var app: Application
    private val started = AtomicBoolean(false)

    // Engine dùng cho run/stop/status
    private val engine = GestureEngine()

    // ------------------------ lifecycle ------------------------

    fun start(ctx: Context, port: Int = 8765) {
        if (started.get()) return
        app = ctx.applicationContext as Application
        val s = Srv(app, port, engine)
        s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        server = s
        started.set(true)
        Log.i("AutoAccess", "HttpServer started on $port")
    }

    fun stop() {
        try {
            server?.stop()
        } catch (_: Throwable) {
        } finally {
            server = null
            started.set(false)
            Log.i("AutoAccess", "HttpServer stopped")
        }
    }

    fun isRunning(): Boolean = started.get()

    // Back-compat cho code cũ
    fun startAsync(ctx: Context) = start(ctx)
    fun stopSafe() = stop()

    // --------------------- impl ---------------------

    private class Srv(
        private val app: Application,
        port: Int,
        private val engine: GestureEngine
    ) : NanoHTTPD(port) {

        override fun serve(session: IHTTPSession): Response {
            return try {
                val path = session.uri ?: "/"
                val method = session.method
                when {
                    method == Method.GET && path == "/ping" -> jsonOk("""{"ok":true}""")
                    method == Method.GET && path == "/status" -> handleStatus()
                    method == Method.POST && path == "/macro" -> handleMacro(session)
                    method == Method.POST && path == "/run" -> handleRun(session)
                    method == Method.POST && path == "/stop" -> handleStop()

                    method == Method.POST && path == "/alias" -> handleAliasSave(session)
                    method == Method.GET && path == "/alias" -> handleAliasList()

                    path == "/image" && method == Method.POST -> handleImageUpload(session)
                    path == "/image" && method == Method.GET  -> handleImageList()
                    path == "/image" && method == Method.DELETE -> handleImageDelete(session)

                    // --- Lệnh trực tiếp:
                    method == Method.POST && path == "/cmd" -> handleCmd(session)

                    else -> jsonError(404, "not_found", "No route for $method $path")
                }
            } catch (t: Throwable) {
                Log.e("AutoAccess", "serve failed", t)
                jsonError(500, "internal_error", t.message ?: "error")
            }
        }

        // ---------- handlers ----------

        private fun handleStatus(): Response {
            val running = engine.isRunning()
            val id = engine.currentMacroId
            val step = engine.currentStep
            val jo = JSONObject()
                .put("running", running)
                .put("id", id)
                .put("step", step)
            return jsonOk(jo.toString())
        }

        private fun handleMacro(session: IHTTPSession): Response {
            val body = readBodyText(session)
            if (body.isEmpty()) return jsonError(400, "bad_request", "empty body")
            val obj = JSONObject(body)
            val macro = MacroParser.parse(obj)

            // Lưu thô để có thể nạp lại sau
            app.getSharedPreferences("macros", Context.MODE_PRIVATE)
                .edit { putString(macro.id, obj.toString()) }

            Log.i("AutoAccess", "macro saved id=${macro.id} steps=${macro.steps.size}")
            val jo = JSONObject().put("ok", true).put("id", macro.id).put("version", macro.version)
            return jsonOk(jo.toString())
        }

        private fun handleRun(session: IHTTPSession): Response {
            val body = readBodyText(session)
            val obj = if (body.isEmpty()) JSONObject() else JSONObject(body)
            val id = obj.optString("id", "")
            if (id.isBlank()) return jsonError(400, "bad_request", "missing id")

            // nạp macro từ prefs
            val sp = app.getSharedPreferences("macros", Context.MODE_PRIVATE)
            val raw = sp.getString(id, null)
                ?: return jsonError(404, "not_found", "macro $id not found")
            val macro = MacroParser.parse(JSONObject(raw))

            engine.run(macro)
            val jo = JSONObject().put("ok", true).put("running", true).put("id", id)
            return jsonOk(jo.toString())
        }

        private fun handleStop(): Response {
            engine.stop()
            return jsonOk("""{"ok":true,"running":false}""")
        }

        private fun handleAliasSave(session: IHTTPSession): Response {
            val body = readBodyText(session)
            if (body.isEmpty()) return jsonError(400, "bad_request", "empty body")
            val obj = JSONObject(body)
            val name = obj.getString("name")

            // chỉ lưu "steps" phần thân dưới dạng JSON
            val stepsJson: String = if (obj.has("steps")) {
                val steps = obj.getJSONArray("steps")
                JSONObject().put("steps", steps).toString()
            } else {
                // cho phép gửi {name, contentJson:"{...}"}
                obj.optString("contentJson", "{\"steps\":[]}")
            }

            AliasRegistry.put(name, stepsJson)

            // lưu vào prefs để tự động nạp lại ở AccessibilitySvc
            app.getSharedPreferences("aliases", Context.MODE_PRIVATE)
                .edit { putString(name, stepsJson) }

            val jo = JSONObject().put("ok", true).put("name", name)
            return jsonOk(jo.toString())
        }

        private fun handleAliasList(): Response {
            // đọc từ prefs (đã nạp vào AliasRegistry khi service connected)
            val sp = app.getSharedPreferences("aliases", Context.MODE_PRIVATE)
            val names = JSONArray()
            for (e in sp.all.keys) names.put(e)
            val jo = JSONObject().put("aliases", names)
            return jsonOk(jo.toString())
        }

        private fun handleImageUpload(session: IHTTPSession): Response {
            val id = session.parms["id"] ?: ""
            if (id.isBlank()) return jsonError(400, "bad_request", "missing id")
            val bytes = readBodyBytes(session)
            if (bytes.isEmpty()) return jsonError(400, "bad_request", "empty content")
            ImageStore.save(app, id, bytes)
            return jsonOk("""{"ok":true,"id":"$id"}""")
        }

        private fun handleImageList(): Response {
            val arr = JSONArray()
            val list: List<Pair<String, ImageStore.Info>> = ImageStore.list(app)
            for (pair in list) {
                val name = pair.first
                val info = pair.second
                val jo = JSONObject()
                    .put("id", name)
                    .put("w", info.outWidth)
                    .put("h", info.outHeight)
                arr.put(jo)
            }
            val out = JSONObject().put("images", arr).toString()
            return jsonOk(out)
        }

        private fun handleImageDelete(session: IHTTPSession): Response {
            val id = session.parms["id"] ?: ""
            if (id.isBlank()) return jsonError(400, "bad_request", "missing id")
            val ok = ImageStore.delete(app, id)
            return jsonOk("""{"ok":$ok}""")
        }

        /** Lệnh trực tiếp: tap/swipe/back/home/recent */
        private fun handleCmd(session: IHTTPSession): Response {
            val body = readBodyText(session)
            if (body.isEmpty()) return jsonError(400, "bad_request", "empty body")
            val jo = JSONObject(body)
            val op = jo.optString("op", "").lowercase(Locale.ROOT)
            val x = jo.optDouble("x", Double.NaN)
            val y = jo.optDouble("y", Double.NaN)
            val x2 = jo.optDouble("x2", Double.NaN)
            val y2 = jo.optDouble("y2", Double.NaN)
            val dur = if (jo.has("dur")) jo.optLong("dur", 1L) else jo.optLong("ms", 1L)

            val svc = AccessibilitySvc.instance
                ?: return jsonError(503, "service_unavailable", "accessibility off")

            when (op) {
                "tap" -> {
                    if (x.isNaN() || y.isNaN()) return jsonError(400, "bad_request", "tap needs x,y")
                    svc.tap(x.toFloat(), y.toFloat(), dur)
                    return jsonOk("""{"ok":true}""")
                }
                "swipe" -> {
                    if (x.isNaN() || y.isNaN() || x2.isNaN() || y2.isNaN())
                        return jsonError(400, "bad_request", "swipe needs x,y,x2,y2")
                    val d = if (dur <= 0) 250L else dur
                    svc.swipe(x.toFloat(), y.toFloat(), x2.toFloat(), y2.toFloat(), d)
                    return jsonOk("""{"ok":true}""")
                }
                "back"   -> { svc.back();   return jsonOk("""{"ok":true}""") }
                "home"   -> { svc.home();   return jsonOk("""{"ok":true}""") }
                "recent" -> { svc.recent(); return jsonOk("""{"ok":true}""") }
                else -> return jsonError(400, "bad_request", "unknown op")
            }
        }

        // ---------- helpers ----------

        private fun contentTypeJson(): String = "application/json; charset=utf-8"

        private fun jsonOk(s: String) =
            newFixedLengthResponse(Response.Status.OK, contentTypeJson(), s)

        private fun jsonError(code: Int, err: String, msg: String) =
            newFixedLengthResponse(
                when (code) {
                    400 -> Response.Status.BAD_REQUEST
                    404 -> Response.Status.NOT_FOUND
                    else -> Response.Status.INTERNAL_ERROR
                },
                contentTypeJson(),
                JSONObject().put("error", err).put("message", msg).toString()
            )

        /** Đọc body text (JSON) – robust cho application/json */
        private fun readBodyText(session: IHTTPSession): String {
            val files = mutableMapOf<String, String>()
            return try {
                session.parseBody(files)
                val p = files["postData"]
                if (p != null) {
                    val f = File(p)
                    when {
                        f.exists() -> f.readText()                  // TH1: NanoHTTPD ghi file tạm -> đường dẫn
                        p.startsWith("{") || p.startsWith("[") -> p // TH2: NanoHTTPD trả raw JSON string
                        else -> ""                                   // không chắc -> rỗng
                    }
                } else {
                    // TH3: fallback – đọc trực tiếp theo Content-Length
                    val len = session.headers["content-length"]?.toIntOrNull() ?: 0
                    if (len > 0) {
                        val buf = ByteArray(len)
                        var read = 0
                        val ins = session.inputStream
                        while (read < len) {
                            val r = ins.read(buf, read, len - read)
                            if (r <= 0) break
                            read += r
                        }
                        String(buf, 0, read, Charsets.UTF_8)
                    } else ""
                }
            } catch (t: Throwable) {
                Log.w("AutoAccess", "readBodyText failed", t)
                ""
            }
        }

        /** Đọc body bytes (upload ảnh) – xử lý cả file path và fallback inputStream */
        private fun readBodyBytes(session: IHTTPSession): ByteArray {
            val ct = session.headers["content-type"]?.lowercase(Locale.ROOT) ?: ""
            // TH1: binary thuần → đọc trực tiếp theo Content-Length
            if (ct.contains("octet-stream") || ct.startsWith("image/")) {
                val len = session.headers["content-length"]?.toIntOrNull() ?: -1
                if (len > 0) {
                    val buf = ByteArray(len)
                    var read = 0
                    val ins = session.inputStream
                    while (read < len) {
                        val r = ins.read(buf, read, len - read)
                        if (r <= 0) break
                        read += r
                    }
                    return buf.copyOf(read)
                }
            }
            // TH2: để NanoHTTPD xử lý multipart/x-www-form-urlencoded
            val files = mutableMapOf<String, String>()
            return try {
                session.parseBody(files)
                // multipart: key là tên field (vd "file"), value là path tạm
                files["postData"]?.let { p -> File(p).takeIf(File::exists)?.readBytes() } ?:
                files.values.firstOrNull()?.let { p -> File(p).takeIf(File::exists)?.readBytes() } ?:
                ByteArray(0)
            } catch (t: Throwable) {
                Log.w("AutoAccess", "readBodyBytes failed", t)
                ByteArray(0)
            }
        }

    }
}
